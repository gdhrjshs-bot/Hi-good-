package com.example.data

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import com.example.model.DisplayModeInfo
import com.example.model.DisplaySpecs

class DisplaySpecsProvider(private val context: Context) {

  fun readDisplaySpecs(): DisplaySpecs {
    val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
    val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
    val metrics: DisplayMetrics = context.resources.displayMetrics

    if (display == null) {
      return DisplaySpecs(
        activeRefreshRateHz = 60f,
        widthPx = metrics.widthPixels,
        heightPx = metrics.heightPixels,
        densityDpi = metrics.densityDpi,
        hdrSupported = false,
        supportedModes = emptyList(),
      )
    }

    val activeMode = display.mode
    val modes =
      display.supportedModes
        .map { mode ->
          DisplayModeInfo(
            modeId = mode.modeId,
            widthPx = mode.physicalWidth,
            heightPx = mode.physicalHeight,
            refreshRateHz = mode.refreshRate,
            isActive = mode.modeId == activeMode.modeId,
          )
        }
        .sortedWith(
          compareByDescending<DisplayModeInfo> { it.refreshRateHz }
            .thenByDescending { it.widthPx * it.heightPx }
        )

    val hdrSupported =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        display.isHdr
      } else {
        @Suppress("DEPRECATION")
        display.hdrCapabilities?.supportedHdrTypes?.isNotEmpty() == true
      }

    return DisplaySpecs(
      activeRefreshRateHz = activeMode.refreshRate,
      widthPx = activeMode.physicalWidth,
      heightPx = activeMode.physicalHeight,
      densityDpi = metrics.densityDpi,
      hdrSupported = hdrSupported,
      supportedModes = modes,
    )
  }

  fun readJsComponentSource(): String {
    return runCatching {
        context.assets.open("fps_monitor.js").bufferedReader().use { it.readText() }
      }
      .getOrDefault("// Unable to load fps_monitor.js from assets")
  }
}
