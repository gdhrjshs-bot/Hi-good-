/**
 * FrameRateMonitor - Standalone JavaScript Web Component (<fps-monitor>)
 * Combines a bouncing glowing-orb smoothness test with a live oscilloscope graph
 * driven by window.requestAnimationFrame() to estimate rendered callback rate in Hz.
 */
class FrameRateMonitor extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });

    // Configurable options
    this.sampleWindowMs = 500;
    this.showOscilloscope = true;

    // Runtime state
    this.isRunning = false;
    this._rafId = null;
    this._lastTimestamp = 0;
    this._lastUiUpdate = 0;
    this._lastBridgePush = 0;

    // Sliding window of rAF timestamps & recent frame deltas
    this._timestamps = [];
    this._deltas = [];
    this._hzHistory = [];
    this._maxHistoryPoints = 96;

    // Session metrics
    this.currentHz = 0;
    this.avgFrameMs = 0;
    this.minHz = Infinity;
    this.maxHz = 0;
    this.hzSum = 0;
    this.hzSamples = 0;
    this.jitterMs = 0;
    this.droppedFrames = 0;
    this.totalFrames = 0;

    // Bouncing orb smoothness track state
    this._dotPos = 0;
    this._dotDir = 1;

    this._tick = this._tick.bind(this);
    this._handleResize = this._handleResize.bind(this);
    this._handleToggleClick = this._handleToggleClick.bind(this);
  }

  connectedCallback() {
    this._render();
    this._cacheElements();
    this._toggleBtn?.addEventListener("click", this._handleToggleClick);
    window.addEventListener("resize", this._handleResize);
    this._handleResize();
    this.start();
  }

  disconnectedCallback() {
    this.pause();
    this._toggleBtn?.removeEventListener("click", this._handleToggleClick);
    window.removeEventListener("resize", this._handleResize);
  }

  _handleToggleClick() {
    if (this.isRunning) {
      this.pause();
    } else {
      this.start();
    }
  }

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this._lastTimestamp = 0;
    this._lastUiUpdate = 0;
    this._updateControlsUi();
    this._rafId = window.requestAnimationFrame(this._tick);
    this._pushBridge(true);
  }

  pause() {
    if (!this.isRunning) return;
    this.isRunning = false;
    if (this._rafId !== null) {
      window.cancelAnimationFrame(this._rafId);
      this._rafId = null;
    }
    this._lastTimestamp = 0;
    this._updateControlsUi();
    this._pushBridge(true);
  }

  reset() {
    this._timestamps = [];
    this._deltas = [];
    this._hzHistory = [];
    this.currentHz = 0;
    this.avgFrameMs = 0;
    this.minHz = Infinity;
    this.maxHz = 0;
    this.hzSum = 0;
    this.hzSamples = 0;
    this.jitterMs = 0;
    this.droppedFrames = 0;
    this.totalFrames = 0;
    this._lastTimestamp = 0;
    this._dotPos = 0;
    this._dotDir = 1;
    if (this._dot) {
      this._dot.style.transform = "translate3d(0px, 0, 0)";
    }
    this._updateReadouts();
    this._drawGraph();
    this._pushBridge(true);
  }

  setSampleWindow(ms) {
    const parsed = Number(ms);
    if (parsed === 250 || parsed === 500 || parsed === 1000) {
      this.sampleWindowMs = parsed;
    }
  }

  setOscilloscopeVisible(visible) {
    this.showOscilloscope = Boolean(visible);
    if (this._oscSection) {
      this._oscSection.style.display = this.showOscilloscope ? "block" : "none";
      if (this.showOscilloscope) {
        this._handleResize();
      }
    }
  }

  /**
   * Core requestAnimationFrame loop calculating live callback rate in Hz
   * and advancing the constant-velocity glowing smoothness orb.
   */
  _tick(now) {
    if (!this.isRunning) return;

    if (this._lastTimestamp > 0) {
      const dt = now - this._lastTimestamp;

      // Ignore extreme gaps caused by app backgrounding (> 500ms)
      if (dt > 0.5 && dt < 500) {
        this.totalFrames += 1;
        this._timestamps.push(now);
        this._deltas.push(dt);
        if (this._deltas.length > 120) {
          this._deltas.shift();
        }

        // Advance bouncing glowing orb smoothly at constant speed
        if (this._track && this._dot) {
          const maxTravel = Math.max(0, this._track.clientWidth - 32);
          if (maxTravel > 0) {
            this._dotPos += this._dotDir * Math.max(1, dt * 0.24);
            if (this._dotPos >= maxTravel) {
              this._dotPos = maxTravel;
              this._dotDir = -1;
            } else if (this._dotPos <= 0) {
              this._dotPos = 0;
              this._dotDir = 1;
            }
            this._dot.style.transform = `translate3d(${this._dotPos.toFixed(1)}px, 0, 0)`;
          }
        }

        // Evict timestamps outside active sampling window
        const cutoff = now - this.sampleWindowMs;
        while (this._timestamps.length > 2 && this._timestamps[0] < cutoff) {
          this._timestamps.shift();
        }

        const span =
          this._timestamps.length >= 2
            ? this._timestamps[this._timestamps.length - 1] - this._timestamps[0]
            : dt;

        if (span >= 80 && this._timestamps.length >= 3) {
          const measuredHz = ((this._timestamps.length - 1) * 1000) / span;
          this.currentHz = measuredHz;
          this.avgFrameMs = 1000 / Math.max(measuredHz, 1);

          if (this.totalFrames > 10) {
            if (measuredHz < this.minHz) this.minHz = measuredHz;
            if (measuredHz > this.maxHz) this.maxHz = measuredHz;
            this.hzSum += measuredHz;
            this.hzSamples += 1;
          }

          if (this.avgFrameMs > 0 && dt > this.avgFrameMs * 1.55) {
            this.droppedFrames += 1;
          }

          this.jitterMs = this._computeStdDev(this._deltas);
        }
      }
    }

    this._lastTimestamp = now;

    // Refresh text & oscilloscope graph at ~15Hz for crisp readability
    if (now - this._lastUiUpdate >= 66) {
      this._lastUiUpdate = now;
      if (this.currentHz > 0) {
        this._hzHistory.push(this.currentHz);
        if (this._hzHistory.length > this._maxHistoryPoints) {
          this._hzHistory.shift();
        }
      }
      this._updateReadouts();
      if (this.showOscilloscope) {
        this._drawGraph();
      }
    }

    // Push telemetry snapshot to Android native ViewModel at ~4Hz
    if (now - this._lastBridgePush >= 250) {
      this._lastBridgePush = now;
      this._pushBridge(false);
    }

    this._rafId = window.requestAnimationFrame(this._tick);
  }

  _computeStdDev(values) {
    const n = values.length;
    if (n < 2) return 0;
    let sum = 0;
    for (let i = 0; i < n; i++) sum += values[i];
    const mean = sum / n;
    let sq = 0;
    for (let i = 0; i < n; i++) {
      const diff = values[i] - mean;
      sq += diff * diff;
    }
    return Math.sqrt(sq / n);
  }

  _getTier(hz) {
    if (hz >= 112) return { label: "120Hz+ ULTRA", color: "#34D399" };
    if (hz >= 84) return { label: "90Hz HIGH", color: "#35D9FF" };
    if (hz >= 54) return { label: "60Hz STANDARD", color: "#60A5FA" };
    if (hz > 0) return { label: "LOW / THROTTLED", color: "#FBBF24" };
    return { label: "RAF TEST", color: "#9AA8C2" };
  }

  _updateControlsUi() {
    if (this._toggleBtn) {
      this._toggleBtn.textContent = this.isRunning
        ? "Stop smoothness test"
        : "Start smoothness test";
      this._toggleBtn.classList.toggle("active", this.isRunning);
    }
    if (this._statusDot) {
      this._statusDot.classList.toggle("paused", !this.isRunning);
    }
  }

  _updateReadouts() {
    if (!this._hzValue) return;
    const hz = this.currentHz;
    const tier = this._getTier(hz);

    this._hzValue.textContent = hz > 0 ? `${hz.toFixed(1)} Hz` : "-- Hz";
    this._hzValue.style.color = hz > 0 ? tier.color : "#35D9FF";
    this._timingEl.textContent =
      this.avgFrameMs > 0
        ? `Average frame time: ${this.avgFrameMs.toFixed(2)} ms`
        : "Average frame time: -- ms";

    this._tierBadge.textContent = tier.label;
    this._tierBadge.style.color = tier.color;
    this._tierBadge.style.borderColor = `${tier.color}44`;
    this._tierBadge.style.backgroundColor = `${tier.color}16`;

    this._jitterEl.textContent = `±${this.jitterMs.toFixed(2)} ms`;
    this._dropsEl.textContent = String(this.droppedFrames);
    this._minMaxEl.textContent =
      this.minHz < Infinity
        ? `${this.minHz.toFixed(0)} / ${this.maxHz.toFixed(0)}`
        : "-- / --";
  }

  _handleResize() {
    if (!this._canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = this._canvas.getBoundingClientRect();
    const w = Math.floor(rect.width);
    const h = Math.floor(rect.height);
    if (w < 10 || h < 10) return;
    this._canvas.width = Math.round(w * dpr);
    this._canvas.height = Math.round(h * dpr);
    const ctx = this._canvas.getContext("2d");
    if (ctx) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    this._drawGraph();
  }

  _drawGraph() {
    if (!this._canvas || !this.showOscilloscope) return;
    const ctx = this._canvas.getContext("2d");
    if (!ctx) return;

    const rect = this._canvas.getBoundingClientRect();
    const w = Math.floor(rect.width);
    const h = Math.floor(rect.height);
    if (w < 10 || h < 10) return;
    ctx.clearRect(0, 0, w, h);

    const maxScale = Math.max(140, Math.ceil((this.maxHz + 15) / 20) * 20);
    const padTop = 14;
    const padBottom = 8;
    const plotH = h - padTop - padBottom;

    const yForHz = (hz) => {
      const clamped = Math.max(0, Math.min(hz, maxScale));
      return padTop + plotH * (1 - clamped / maxScale);
    };

    const guides = [60, 90, 120];
    ctx.save();
    ctx.font = "600 10px monospace";
    ctx.textBaseline = "middle";
    for (const g of guides) {
      if (g > maxScale) continue;
      const y = yForHz(g);
      ctx.strokeStyle =
        g === 120 ? "rgba(52, 211, 153, 0.28)" : "rgba(154, 168, 194, 0.16)";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();

      ctx.setLineDash([]);
      ctx.fillStyle =
        g === 120 ? "rgba(52, 211, 153, 0.85)" : "rgba(154, 168, 194, 0.7)";
      ctx.fillText(`${g}Hz`, 4, y - 7);
    }
    ctx.restore();

    const pts = this._hzHistory;
    if (pts.length < 2) return;

    const stepX = w / (this._maxHistoryPoints - 1);
    const startX = w - (pts.length - 1) * stepX;

    const areaGrad = ctx.createLinearGradient(0, padTop, 0, h);
    areaGrad.addColorStop(0, "rgba(53, 217, 255, 0.30)");
    areaGrad.addColorStop(1, "rgba(154, 104, 255, 0.0)");

    ctx.beginPath();
    ctx.moveTo(startX, h - padBottom);
    for (let i = 0; i < pts.length; i++) {
      ctx.lineTo(startX + i * stepX, yForHz(pts[i]));
    }
    ctx.lineTo(startX + (pts.length - 1) * stepX, h - padBottom);
    ctx.closePath();
    ctx.fillStyle = areaGrad;
    ctx.fill();

    const lineGrad = ctx.createLinearGradient(0, 0, w, 0);
    lineGrad.addColorStop(0, "#35D9FF");
    lineGrad.addColorStop(0.55, "#9A68FF");
    lineGrad.addColorStop(1, "#34D399");

    ctx.beginPath();
    for (let i = 0; i < pts.length; i++) {
      const x = startX + i * stepX;
      const y = yForHz(pts[i]);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = lineGrad;
    ctx.lineWidth = 2.4;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.stroke();

    const lastX = startX + (pts.length - 1) * stepX;
    const lastY = yForHz(pts[pts.length - 1]);
    ctx.beginPath();
    ctx.arc(lastX, lastY, 4.2, 0, Math.PI * 2);
    ctx.fillStyle = "#34D399";
    ctx.fill();
  }

  _pushBridge(force) {
    if (!window.AndroidHzBridge || typeof window.AndroidHzBridge.onTelemetry !== "function") {
      return;
    }
    const avgHz = this.hzSamples > 0 ? this.hzSum / this.hzSamples : this.currentHz;
    const payload = JSON.stringify({
      currentHz: Number(this.currentHz.toFixed(2)),
      avgFrameMs: Number(this.avgFrameMs.toFixed(2)),
      minHz: this.minHz < Infinity ? Number(this.minHz.toFixed(1)) : 0,
      maxHz: Number(this.maxHz.toFixed(1)),
      avgHz: Number(avgHz.toFixed(1)),
      jitterMs: Number(this.jitterMs.toFixed(2)),
      droppedFrames: this.droppedFrames,
      totalFrames: this.totalFrames,
      isRunning: this.isRunning,
      sampleWindowMs: this.sampleWindowMs,
      forced: Boolean(force),
    });
    try {
      window.AndroidHzBridge.onTelemetry(payload);
    } catch (_) {
      // Ignore detached bridge errors
    }
  }

  _cacheElements() {
    const root = this.shadowRoot;
    this._hzValue = root.getElementById("fps");
    this._timingEl = root.getElementById("timing");
    this._tierBadge = root.getElementById("tierBadge");
    this._statusDot = root.getElementById("statusDot");
    this._track = root.getElementById("track");
    this._dot = root.getElementById("dot");
    this._toggleBtn = root.getElementById("toggle");
    this._jitterEl = root.getElementById("jitterMs");
    this._dropsEl = root.getElementById("drops");
    this._minMaxEl = root.getElementById("minMax");
    this._oscSection = root.getElementById("oscSection");
    this._canvas = root.getElementById("graph");
  }

  _render() {
    this.shadowRoot.innerHTML = `
      <style>
        * { box-sizing: border-box; }
        :host {
          display: block;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          color: #FFFFFF;
          user-select: none;
          -webkit-user-select: none;
        }
        .panel {
          background: radial-gradient(circle at 86% 6%, rgba(53, 217, 255, 0.14), transparent 46%),
                      linear-gradient(165deg, #121A2B 0%, #0C1324 100%);
          border: 1px solid rgba(154, 168, 194, 0.2);
          border-radius: 22px;
          padding: 18px;
        }
        .top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
        }
        .label-row {
          display: inline-flex;
          align-items: center;
          gap: 7px;
        }
        .dot-live {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #34D399;
          box-shadow: 0 0 10px #34D399;
        }
        .dot-live.paused {
          background: #FBBF24;
          box-shadow: none;
        }
        .label {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 1.5px;
          color: #9AA8C2;
          font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        }
        .tier {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.08em;
          padding: 5px 10px;
          border-radius: 999px;
          border: 1px solid rgba(53, 217, 255, 0.35);
          background: rgba(53, 217, 255, 0.12);
          color: #35D9FF;
          font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
          white-space: nowrap;
        }
        #fps {
          font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
          font-variant-numeric: tabular-nums;
          font-size: 42px;
          font-weight: 800;
          color: #35D9FF;
          line-height: 1.08;
          margin-top: 8px;
        }
        #timing {
          font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
          font-size: 12px;
          color: #9AA8C2;
          margin-top: 4px;
        }
        .track {
          height: 68px;
          border-radius: 14px;
          background: repeating-linear-gradient(
            90deg,
            rgba(154, 168, 194, 0.07) 0px,
            rgba(154, 168, 194, 0.07) 1px,
            transparent 1px,
            transparent 24px
          ), #0A1020;
          border: 1px solid rgba(154, 168, 194, 0.18);
          margin-top: 14px;
          overflow: hidden;
          position: relative;
        }
        #dot {
          position: absolute;
          top: 18px;
          left: 0;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: radial-gradient(circle at 35% 35%, #67E8F9 0%, #35D9FF 45%, #9A68FF 100%);
          border: 2px solid rgba(255, 255, 255, 0.35);
        }
        .actions {
          margin-top: 14px;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        button#toggle {
          border: 0;
          border-radius: 12px;
          padding: 13px 18px;
          min-height: 48px;
          width: 100%;
          background: #35D9FF;
          color: #08101B;
          font-weight: 700;
          font-size: 14px;
          cursor: pointer;
          transition: opacity 0.15s ease;
        }
        button#toggle.active {
          background: rgba(53, 217, 255, 0.16);
          color: #35D9FF;
          border: 1px solid rgba(53, 217, 255, 0.45);
        }
        .metrics {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 8px;
          margin-top: 14px;
        }
        .metric-card {
          background: rgba(10, 16, 32, 0.72);
          border: 1px solid rgba(154, 168, 194, 0.15);
          border-radius: 12px;
          padding: 9px 10px;
        }
        .metric-label {
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #9AA8C2;
          margin-bottom: 3px;
        }
        .metric-val {
          font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
          font-variant-numeric: tabular-nums;
          font-size: 13px;
          font-weight: 700;
          color: #F8FAFC;
        }
        .osc-section {
          margin-top: 14px;
          background: rgba(6, 10, 20, 0.74);
          border: 1px solid rgba(154, 168, 194, 0.16);
          border-radius: 14px;
          padding: 8px 10px 6px 10px;
        }
        .osc-title {
          display: flex;
          justify-content: space-between;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #9AA8C2;
          margin-bottom: 4px;
        }
        canvas {
          display: block;
          width: 100%;
          height: 112px;
        }
        .note {
          font-size: 11px;
          color: #9AA8C2;
          line-height: 1.45;
          margin-top: 12px;
        }
      </style>
      <div class="panel">
        <div class="top">
          <div>
            <div class="label-row">
              <span id="statusDot" class="dot-live"></span>
              <span class="label">LIVE CALLBACK RATE</span>
            </div>
            <div id="fps">-- Hz</div>
            <div id="timing">Average frame time: -- ms</div>
          </div>
          <div id="tierBadge" class="tier">RAF TEST</div>
        </div>

        <div id="track" class="track">
          <div id="dot"></div>
        </div>

        <div class="actions">
          <button id="toggle" type="button">Stop smoothness test</button>
        </div>

        <div class="metrics">
          <div class="metric-card">
            <div class="metric-label">Min / Max</div>
            <div id="minMax" class="metric-val">-- / --</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">Jitter</div>
            <div id="jitterMs" class="metric-val">±0.00 ms</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">Drops</div>
            <div id="drops" class="metric-val">0</div>
          </div>
        </div>

        <div id="oscSection" class="osc-section">
          <div class="osc-title">
            <span>Oscilloscope (requestAnimationFrame)</span>
            <span>RAF TEST</span>
          </div>
          <canvas id="graph"></canvas>
        </div>

        <div class="note">
          This measures the rate at which the WebView receives animation frames. It is an estimate of rendered FPS, not a guaranteed hardware refresh-rate reading.
        </div>
      </div>
    `;
  }
}

if (!customElements.get("fps-monitor")) {
  customElements.define("fps-monitor", FrameRateMonitor);
}

window.fpsMonitor = {
  getElement: () => document.querySelector("fps-monitor"),
  start: () => document.querySelector("fps-monitor")?.start(),
  pause: () => document.querySelector("fps-monitor")?.pause(),
  reset: () => document.querySelector("fps-monitor")?.reset(),
  setSampleWindow: (ms) => document.querySelector("fps-monitor")?.setSampleWindow(ms),
  setOscilloscopeVisible: (visible) =>
    document.querySelector("fps-monitor")?.setOscilloscopeVisible(visible),
};
