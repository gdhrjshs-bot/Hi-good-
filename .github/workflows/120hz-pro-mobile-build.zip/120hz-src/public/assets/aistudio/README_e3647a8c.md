# 120HZ Android project (version 1.1)

A legitimate Android display utility prototype.

## Features
- Reads the active display refresh rate and resolution using Android `Display` APIs.
- Lists supported display modes and refresh rates.
- Includes a JavaScript live frame-rate / smoothness monitor using `requestAnimationFrame` in a local WebView asset.
- Includes game preference selectors for Free Fire / Free Fire MAX, graphics preference, and target FPS preference.

## Important limitations
- The JavaScript monitor measures the rate at which WebView animation frames are delivered. This is a rendered-frame estimate, not a guaranteed hardware refresh-rate reading.
- Display refresh-rate and resolution information comes from Android's display mode APIs.
- The app does not root the phone, use privilege escalation, patch game files, bypass licensing, unlock unsupported FPS, or force a display mode.
- The system display settings button is a UI placeholder in this starter build; use the phone's Settings app to change supported display options. Android/device manufacturers may restrict programmatic mode changes.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location.
