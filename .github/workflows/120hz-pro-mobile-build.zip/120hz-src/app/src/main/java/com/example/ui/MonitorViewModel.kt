package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DisplaySpecsProvider
import com.example.data.PreferencesRepository
import com.example.model.DisplayReadiness
import com.example.model.DisplayReadinessStatus
import com.example.model.DisplaySpecs
import com.example.model.GameTitle
import com.example.model.GraphicsTier
import com.example.model.JsCommand
import com.example.model.JsTelemetrySnapshot
import com.example.model.MonitorTab
import com.example.model.MonitorUiState
import com.example.model.UserPreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

class MonitorViewModel(application: Application) : AndroidViewModel(application) {

  private val specsProvider = DisplaySpecsProvider(application.applicationContext)
  private val preferencesRepository = PreferencesRepository(application.applicationContext)

  private val initialSpecs = specsProvider.readDisplaySpecs()
  private val initialPrefs = UserPreferences()

  private val _uiState =
    MutableStateFlow(
      MonitorUiState(
        displaySpecs = initialSpecs,
        preferences = initialPrefs,
        readiness = computeReadiness(initialSpecs, initialPrefs.targetFps),
        jsSourceCode = specsProvider.readJsComponentSource(),
      )
    )
  val uiState: StateFlow<MonitorUiState> = _uiState.asStateFlow()

  private val _commands = MutableSharedFlow<JsCommand>(extraBufferCapacity = 16)
  val commands: SharedFlow<JsCommand> = _commands.asSharedFlow()

  init {
    viewModelScope.launch {
      preferencesRepository.preferencesFlow.collect { prefs ->
        _uiState.update { state ->
          state.copy(
            preferences = prefs,
            readiness = computeReadiness(state.displaySpecs, prefs.targetFps),
          )
        }
        _commands.emit(JsCommand.SetWindow(prefs.sampleWindowMs))
        _commands.emit(JsCommand.SetOscilloscope(prefs.showOscilloscope))
      }
    }
  }

  fun selectTab(tab: MonitorTab) {
    _uiState.update { it.copy(activeTab = tab) }
    if (tab == MonitorTab.DISPLAY || tab == MonitorTab.PRESETS) {
      refreshDisplaySpecs()
    }
  }

  fun refreshDisplaySpecs() {
    val specs = specsProvider.readDisplaySpecs()
    _uiState.update { state ->
      state.copy(
        displaySpecs = specs,
        readiness = computeReadiness(specs, state.preferences.targetFps),
      )
    }
  }

  fun toggleRunning() {
    val nextRunning = !_uiState.value.telemetry.isRunning
    _uiState.update { state ->
      state.copy(telemetry = state.telemetry.copy(isRunning = nextRunning))
    }
    emitCommand(if (nextRunning) JsCommand.Start else JsCommand.Pause)
  }

  fun resetStats() {
    _uiState.update { state ->
      state.copy(
        telemetry =
          JsTelemetrySnapshot(
            isRunning = state.telemetry.isRunning,
            sampleWindowMs = state.preferences.sampleWindowMs,
          )
      )
    }
    emitCommand(JsCommand.Reset)
  }

  fun setSampleWindow(windowMs: Int) {
    if (windowMs !in setOf(250, 500, 1000)) return
    viewModelScope.launch { preferencesRepository.setSampleWindowMs(windowMs) }
    emitCommand(JsCommand.SetWindow(windowMs))
  }

  fun setShowOscilloscope(visible: Boolean) {
    viewModelScope.launch { preferencesRepository.setShowOscilloscope(visible) }
    emitCommand(JsCommand.SetOscilloscope(visible))
  }

  fun selectGame(game: GameTitle) {
    viewModelScope.launch { preferencesRepository.setSelectedGame(game) }
  }

  fun selectGraphics(tier: GraphicsTier) {
    viewModelScope.launch { preferencesRepository.setGraphicsPreference(tier) }
  }

  fun selectTargetFps(fps: Int) {
    if (fps !in setOf(60, 90, 120)) return
    viewModelScope.launch { preferencesRepository.setTargetFps(fps) }
  }

  fun resetGamePreferences() {
    viewModelScope.launch { preferencesRepository.resetGamePreferences() }
  }

  fun onJsTelemetryJson(rawJson: String) {
    val parsed = parseTelemetry(rawJson) ?: return
    _uiState.update { it.copy(telemetry = parsed) }
  }

  private fun emitCommand(command: JsCommand) {
    viewModelScope.launch { _commands.emit(command) }
  }

  private fun computeReadiness(specs: DisplaySpecs, targetFps: Int): DisplayReadiness {
    val tolerance = 2.0f
    val activeHz = specs.activeRefreshRateHz
    val maxHz = specs.maxSupportedRefreshRateHz
    val status =
      when {
        activeHz + tolerance >= targetFps -> DisplayReadinessStatus.READY
        maxHz + tolerance >= targetFps -> DisplayReadinessStatus.SWITCH_DISPLAY_MODE
        else -> DisplayReadinessStatus.HARDWARE_LIMITED
      }
    return DisplayReadiness(
      status = status,
      activeHz = activeHz,
      maxSupportedHz = maxHz,
      targetFps = targetFps,
    )
  }

  private fun parseTelemetry(rawJson: String): JsTelemetrySnapshot? {
    return runCatching {
        val obj = JSONObject(rawJson)
        val currentHz = obj.optDouble("currentHz", 0.0).coerceIn(0.0, 1000.0)
        val avgFrameMs = obj.optDouble("avgFrameMs", 0.0).coerceIn(0.0, 1000.0)
        val minHz = obj.optDouble("minHz", 0.0).coerceIn(0.0, 1000.0)
        val maxHz = obj.optDouble("maxHz", 0.0).coerceIn(0.0, 1000.0)
        val avgHz = obj.optDouble("avgHz", 0.0).coerceIn(0.0, 1000.0)
        val jitterMs = obj.optDouble("jitterMs", 0.0).coerceIn(0.0, 500.0)
        val dropped = obj.optInt("droppedFrames", 0).coerceAtLeast(0)
        val total = obj.optInt("totalFrames", 0).coerceAtLeast(0)
        val isRunning = obj.optBoolean("isRunning", true)
        val windowMs = obj.optInt("sampleWindowMs", 500).coerceIn(100, 5000)

        JsTelemetrySnapshot(
          currentHz = if (currentHz.isFinite()) currentHz else 0.0,
          avgFrameMs = if (avgFrameMs.isFinite()) avgFrameMs else 0.0,
          minHz = if (minHz.isFinite()) minHz else 0.0,
          maxHz = if (maxHz.isFinite()) maxHz else 0.0,
          avgHz = if (avgHz.isFinite()) avgHz else 0.0,
          jitterMs = if (jitterMs.isFinite()) jitterMs else 0.0,
          droppedFrames = dropped,
          totalFrames = total,
          isRunning = isRunning,
          sampleWindowMs = windowMs,
        )
      }
      .getOrNull()
  }
}
