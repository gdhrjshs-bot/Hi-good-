# 120hz Display Utility & Smoothness Monitor (v1.1)

Upgrade the **120hz** Android display utility to incorporate your v1.1 specification: combining your attached JavaScript `requestAnimationFrame` bouncing-dot smoothness test with live frame-rate telemetry, full Android `Display` hardware mode inspection, and locally persisted game preference selectors for Free Fire and Free Fire MAX with real-time display compatibility checks.

## User Review & Critical Decisions

> [!IMPORTANT]
> Because the clarifying questions were skipped, this plan uses the recommended defaults below. Review these decisions and click **Proceed** to build, or reply with any adjustments you would like first.

- **JavaScript Smoothness Monitor**: Combines your attached bouncing glowing cyan-purple dot track (`LIVE CALLBACK RATE`, `RAF TEST`, `Start/Stop smoothness test`, and the explicit rendered-FPS disclaimer) with the live oscilloscope waveform and frame-timing metrics inside the local WebView component.
- **Game Preference Selectors**: Adds a dedicated **Presets** experience for **Free Fire** and **Free Fire MAX** with Graphics Preference (`Smooth`, `Standard`, `Ultra`, `Max`) and Target FPS Preference (`60 FPS`, `90 FPS`, `120 FPS`), saved locally on-device with Jetpack DataStore and compared live against your phone's actual supported display refresh rates.
- **Display Settings Action**: Wires the system Display Settings button directly to Android's native Display Settings screen (`ACTION_DISPLAY_SETTINGS`), with a graceful fallback notice if a device OEM restricts direct intents.
- **Legitimate Utility Boundaries**: Strictly honors your README's transparency rules—this app only reads standard Android `Display` APIs and WebView `requestAnimationFrame` callbacks. It does not root the device, patch game files, bypass licensing, or force unsupported hardware modes.

---

## 1. Overview & Core Concept

- **What It Does**: **120hz** is a transparent, precision Android display utility that inspects active and supported hardware display modes, runs a real-time JavaScript `requestAnimationFrame` smoothness test in an isolated local WebView, and lets players organize and validate their Free Fire / Free Fire MAX graphics and target FPS preferences against what their device screen actually supports.
- **Target Audience / Persona**: Mobile gamers and Android enthusiasts who want to verify whether their phone is actively running at 60Hz, 90Hz, or 120Hz, visually inspect motion smoothness, and check if their preferred in-game FPS targets match their display hardware.
- **Key Value**: Brings honest hardware refresh-rate inspection, visual motion verification, and local game preference readiness checks into one fast, dark-themed instrument without root access or risky system modifications.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Live Smoothness & Callback Monitor (Monitor Tab)**:
   - Opens directly into the **120hz** live monitor displaying the active header badge (`LIVE rAF` / `PAUSED`) and the embedded JavaScript `requestAnimationFrame` component.
   - Users see the **LIVE CALLBACK RATE** (`-- Hz`), average frame time (`ms`), the bouncing cyan-to-violet glowing orb across the dark motion track, and the live oscilloscope waveform.
   - Tapping **Start / Stop smoothness test** (either inside the JS component or via the synchronized native controls) immediately starts or pauses the `requestAnimationFrame` loop; users can also reset statistics, adjust the sampling window (`250ms` / `500ms` / `1000ms`), and compare the JS callback rate side-by-side against Android's reported active `Display.Mode` refresh rate.
   - An always-visible transparency note clearly states that the JavaScript test estimates rendered WebView frame delivery rather than a guaranteed hardware panel scan rate.

2. **Game Preferences & Compatibility Check (Presets Tab)**:
   - Users choose between **Free Fire** and **Free Fire MAX** via segmented cards.
   - Users select a **Graphics Preference** (`Smooth`, `Standard`, `Ultra`, `Max`) and a **Target FPS Preference** (`60 FPS`, `90 FPS`, `120 FPS`).
   - A live **Display Readiness Banner** automatically evaluates the chosen target FPS against the phone's active refresh rate and maximum supported hardware mode:
     - **Ready**: Active display mode meets or exceeds the selected target FPS.
     - **Settings Needed**: Device supports the target refresh rate in hardware, but is currently running at a lower mode—provides a direct shortcut to Android Display Settings.
     - **Hardware Limited**: Device display max refresh rate is below the target FPS—clearly explains the hardware cap without misleading claims.
   - Selections persist automatically across app restarts via local DataStore preferences.

3. **Hardware Display Modes (Display Tab)**:
   - Displays a hero hardware readout of the active refresh rate (`Hz`), physical resolution (`px`), screen density (`dpi`), and HDR support status.
   - Lists every supported `Display.Mode` sorted from highest refresh rate to lowest, highlighting the currently active mode with an emerald `ACTIVE` pill and per-frame time budget (`ms/frame`).
   - Provides a working **Open System Display Settings** button and a **Refresh Hardware Info** action to re-read modes after returning from system settings.

4. **Inspectable JS Component (JS Code Tab)**:
   - Displays the live JavaScript `requestAnimationFrame` source code in a scrollable monospace code card with a one-tap **Copy JS** button and confirmation snackbar.

### Visual Identity & Theme

- **Aesthetic Direction**: **Precision Telemetry Dark**—an instrument-grade dark interface inspired by broadcast oscilloscopes and hardware profilers, combining deep obsidian surfaces with crisp hairline borders and high-contrast luminous cyan/violet/emerald telemetry accents.
- **Color Palette & Mood**:
  - Background (`background`): Deep Obsidian (`#090D16`)
  - Primary Surface (`surface` / `surfaceVariant`): Midnight Slate (`#111A2E` / `#18243E`) with subtle borders (`#28354F`)
  - Primary Accent (`primary`): Electric Cyan (`#22D3EE` / `#35D9FF`) matching the attached smoothness monitor
  - Secondary Accent (`secondary`): Signal Emerald (`#34D399`) for active hardware modes and compatible readiness states, paired with Soft Violet (`#9A68FF`) on the smoothness test orb gradient
  - Warning / Caution (`tertiary`): Signal Amber (`#FBBF24`) for paused states or refresh-rate mismatches
- **Typography & Hierarchy**:
  - **Space Grotesk** (bundled locally) for titles, section headers, buttons, and body copy.
  - **JetBrains Mono** (bundled locally) with tabular numeric alignment for Hz readings, millisecond frame times, display mode specs, badges, and JS source code.
- **Component Styling & Layout**:
  - Material Design 3 surfaces (`RoundedCornerShape` 16–22dp), `FilterChip` selectors, 48dp minimum interactive touch targets, full edge-to-edge rendering with `WindowInsets.safeDrawing` / `WindowInsets.navigationBars`.
  - Responsive layouts adapt seamlessly between compact phones (bottom `NavigationBar`, single-column centered up to `620dp`) and tablets/foldables (left `NavigationRail`, two-column split view on Monitor and Presets screens).

### Interactive Feedback & Motion

- Smooth `spring()` height transitions when toggling visual telemetry sections.
- Immediate visual state feedback on Start/Stop toggle, active chip selection, hardware mode re-check on resume, and snackbar confirmation when copying JS source or resetting preferences.
- Hardware back navigation from secondary tabs cleanly returns to the primary Monitor tab.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Unified JavaScript Smoothness & Oscilloscope Component**
  - *Chosen Approach*: Upgrade the local WebView component so it renders your attached bouncing glowing-orb smoothness track (`LIVE CALLBACK RATE`, `RAF TEST`, `Start/Stop smoothness test`, and disclaimer note) together with the live Hz oscilloscope graph and frame-timing metrics, all driven by a single `window.requestAnimationFrame` loop.
  - *Why*: Preserves the exact visual test and clear user disclaimer from your attached HTML while giving power users deeper stability metrics (min/max Hz, jitter, drops, oscilloscope history) without running duplicate animation loops.
  - *Alternatives Considered*: Replacing the oscilloscope completely with the minimal HTML file (loses stability waveform and session stats) or running two separate WebViews (wastes memory and causes competing frame callbacks).

- **Decision 2: Local Client-Only Preference Storage with Jetpack DataStore**
  - *Chosen Approach*: Store the user's selected game (`Free Fire` / `Free Fire MAX`), graphics preference, target FPS preference, sampling window, and smoothness display toggle in Android **Jetpack DataStore (Preferences)**.
  - *Why*: These are lightweight device-local UI preferences tied to the specific phone's display hardware. DataStore provides asynchronous, type-safe persistence with zero sign-in friction and minimal APK footprint.
  - *Alternatives Considered*: Cloud database (unnecessary overhead and login friction for device-specific hardware settings) or in-memory state only (loses selected game presets whenever the app closes).

- **Decision 3: Hardware Compatibility Evaluation Instead of Forced Overrides**
  - *Chosen Approach*: Compare the user's selected target FPS (`60` / `90` / `120`) directly against Android's `Display.getMode()` and `Display.getSupportedModes()` and link to Android's native `Settings.ACTION_DISPLAY_SETTINGS`.
  - *Why*: Completely respects Android security boundaries and Google Play policies while giving users actionable, honest feedback on whether their phone's screen is ready for their target frame rate.
  - *Alternatives Considered*: Non-functional placeholder button (dead-end UI) or private/root APIs (unsafe and unsupported).

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                         Android Activity (Edge-to-Edge)                   │
│             Adaptive Navigation Shell (NavigationBar / Rail)              │
└────────────────────────────────────┬──────────────────────────────────────┘
                                     │ observes StateFlow / dispatches intents
                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                            MonitorViewModel                               │
│  • Combines live JS telemetry, hardware DisplaySpecs, & DataStore prefs   │
│  • Computes Display Readiness (Ready / Settings Needed / Hardware Cap)    │
│  • Emits JsCommand events (Start, Pause, Reset, Window, Visual toggles)   │
└───────────┬────────────────────────┬──────────────────────────┬───────────┘
            │                        │                          │
            ▼                        ▼                          ▼
┌──────────────────────┐  ┌───────────────────────┐  ┌──────────────────────┐
│  Local Asset Host &  │  │ DisplaySpecsProvider  │  │ PreferencesRepository│
│  Secure WebView      │  │ (Android Display API) │  │ (Jetpack DataStore)  │
│  • Local HTML/JS     │  │ • Active refresh Hz   │  │ • Game title         │
│  • rAF Bouncing Orb  │  │ • Supported modes     │  │ • Graphics tier      │
│  • Oscilloscope      │  │ • Resolution & DPI    │  │ • Target FPS (Hz)    │
│  • JS <-> Kotlin     │  │ • HDR capability      │  │ • Sampling window    │
│    Telemetry Bridge  │  │ • Auto-refresh on     │  │ • Smoothness options │
└───────────┬──────────┘  │   Activity resume     │  └──────────────────────┘
            │             └───────────────────────┘
            ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                               UI Screens                                  │
│  ┌──────────────┐  ┌───────────────┐  ┌───────────────┐  ┌─────────────┐  │
│  │ Monitor Tab  │  │  Presets Tab  │  │  Display Tab  │  │ JS Code Tab │  │
│  │ JS Orb + rAF │  │ Game/GFX/FPS  │  │ Hardware Spec │  │ Source View │  │
│  │ Graph & Sync │  │ Compatibility │  │ Modes & Link  │  │ Copy Action │  │
│  └──────────────┘  └───────────────┘  └───────────────┘  └─────────────┘  │
└───────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **JavaScript Telemetry Snapshot**: Live callback rate (`Hz`), average frame time (`ms`), min/max/avg `Hz`, jitter (`ms`), dropped frame count, total sampled frames, active running flag, and sampling window (`ms`).
- **Hardware Display Specs**: Active refresh rate (`Hz`), physical width/height (`px`), density (`dpi`), HDR support boolean, and ordered list of supported `Display.Mode` entries (marking active mode).
- **Game Preference Profile (Persisted via DataStore)**:
  - `selectedGame`: `Free Fire` or `Free Fire MAX`
  - `graphicsPreference`: `Smooth`, `Standard`, `Ultra`, or `Max`
  - `targetFps`: `60`, `90`, or `120`
  - `sampleWindowMs`: `250`, `500`, or `1000`
  - `showOscilloscope`: boolean toggle for expanding/collapsing the live waveform graph below the bouncing-orb track
- **Display Readiness Result (Derived)**: Computed cleanly from `targetFps` vs. `activeRefreshRateHz` and `maxSupportedRefreshRateHz` into three states (`READY`, `SWITCH_DISPLAY_MODE`, `HARDWARE_LIMITED`) with clear guidance text.

### Interactive Component & State Mapping

- **Smoothness Test Toggle (WebView Button & Native Button)**: Both controls stay strictly synchronized via the JS-to-Kotlin bridge (`AndroidHzBridge`) and Kotlin-to-JS command dispatch (`window.fpsMonitor.start()/pause()`). Starting clears stale timestamps and immediately animates the glowing cyan-violet orb; stopping cancels `requestAnimationFrame` and freezes/clears live readouts cleanly.
- **Sampling Window & Reset Controls**: Updating `250ms` / `500ms` / `1000ms` writes to DataStore and immediately updates the active sliding window inside the JS `requestAnimationFrame` engine. Reset clears session min/max/drops and resets the oscilloscope canvas.
- **Game Preference Selectors (Presets Tab)**: Tapping a game card, graphics chip, or target FPS chip immediately updates state, persists asynchronously to DataStore, and recalculates the Display Readiness Banner in real time.
- **Lifecycle & System Settings Return**: Whenever the Activity resumes (such as after the user switches refresh rate in Android's Display Settings), `DisplaySpecsProvider` automatically re-queries `DisplayManager` so both the Display tab and the Presets Readiness Banner reflect the new hardware refresh rate immediately.
- **Security & Isolation**: The WebView intercepts requests strictly for the bundled local HTML/JS monitor assets over a synthetic HTTPS asset origin, blocks all external navigation, disables file/content URL access, and validates/clamps all incoming JSON bridge values before updating UI state.
