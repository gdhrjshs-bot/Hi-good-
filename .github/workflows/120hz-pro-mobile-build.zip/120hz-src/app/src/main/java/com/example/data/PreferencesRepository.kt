package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.GameTitle
import com.example.model.GraphicsTier
import com.example.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.monitorDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "hz_monitor_preferences")

class PreferencesRepository(private val context: Context) {

  private object Keys {
    val SELECTED_GAME = stringPreferencesKey("selected_game")
    val GRAPHICS_PREF = stringPreferencesKey("graphics_preference")
    val TARGET_FPS = intPreferencesKey("target_fps")
    val SAMPLE_WINDOW_MS = intPreferencesKey("sample_window_ms")
    val SHOW_OSCILLOSCOPE = booleanPreferencesKey("show_oscilloscope")
  }

  val preferencesFlow: Flow<UserPreferences> =
    context.monitorDataStore.data.map { prefs ->
      UserPreferences(
        selectedGame = GameTitle.fromKey(prefs[Keys.SELECTED_GAME]),
        graphicsPreference = GraphicsTier.fromKey(prefs[Keys.GRAPHICS_PREF]),
        targetFps = prefs[Keys.TARGET_FPS]?.takeIf { it in VALID_FPS } ?: 120,
        sampleWindowMs = prefs[Keys.SAMPLE_WINDOW_MS]?.takeIf { it in VALID_WINDOWS } ?: 500,
        showOscilloscope = prefs[Keys.SHOW_OSCILLOSCOPE] ?: true,
      )
    }

  suspend fun setSelectedGame(game: GameTitle) {
    context.monitorDataStore.edit { it[Keys.SELECTED_GAME] = game.storageKey }
  }

  suspend fun setGraphicsPreference(tier: GraphicsTier) {
    context.monitorDataStore.edit { it[Keys.GRAPHICS_PREF] = tier.storageKey }
  }

  suspend fun setTargetFps(fps: Int) {
    if (fps !in VALID_FPS) return
    context.monitorDataStore.edit { it[Keys.TARGET_FPS] = fps }
  }

  suspend fun setSampleWindowMs(windowMs: Int) {
    if (windowMs !in VALID_WINDOWS) return
    context.monitorDataStore.edit { it[Keys.SAMPLE_WINDOW_MS] = windowMs }
  }

  suspend fun setShowOscilloscope(visible: Boolean) {
    context.monitorDataStore.edit { it[Keys.SHOW_OSCILLOSCOPE] = visible }
  }

  suspend fun resetGamePreferences() {
    context.monitorDataStore.edit { prefs ->
      prefs[Keys.SELECTED_GAME] = GameTitle.FREE_FIRE_MAX.storageKey
      prefs[Keys.GRAPHICS_PREF] = GraphicsTier.ULTRA.storageKey
      prefs[Keys.TARGET_FPS] = 120
    }
  }

  private companion object {
    val VALID_FPS = setOf(60, 90, 120)
    val VALID_WINDOWS = setOf(250, 500, 1000)
  }
}
