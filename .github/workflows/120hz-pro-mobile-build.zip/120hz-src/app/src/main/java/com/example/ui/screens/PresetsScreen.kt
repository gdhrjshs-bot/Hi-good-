package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.DisplayReadiness
import com.example.model.DisplayReadinessStatus
import com.example.model.GameTitle
import com.example.model.GraphicsTier
import com.example.model.MonitorUiState
import com.example.ui.theme.JetBrainsMonoFontFamily
import java.util.Locale

@Composable
fun PresetsScreen(
  uiState: MonitorUiState,
  onSelectGame: (GameTitle) -> Unit,
  onSelectGraphics: (GraphicsTier) -> Unit,
  onSelectTargetFps: (Int) -> Unit,
  onResetPresets: () -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val settingsUnavailableMsg = stringResource(R.string.action_settings_unavailable)
  val presetsResetMsg = stringResource(R.string.action_presets_reset)

  val openDisplaySettings: () -> Unit = {
    val launched =
      runCatching {
          context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        .isSuccess
    if (!launched) {
      onShowMessage(settingsUnavailableMsg)
    }
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 720.dp

    if (isWide) {
      Row(
        modifier =
          Modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp),
        verticalAlignment = Alignment.Top,
      ) {
        Column(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          ReadinessBannerCard(
            readiness = uiState.readiness,
            selectedGame = uiState.preferences.selectedGame,
            onOpenSettings = openDisplaySettings,
          )
          GameSelectorCard(
            selectedGame = uiState.preferences.selectedGame,
            onSelectGame = onSelectGame,
          )
        }
        Column(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          GraphicsPreferenceCard(
            selectedTier = uiState.preferences.graphicsPreference,
            onSelectTier = onSelectGraphics,
          )
          TargetFpsPreferenceCard(
            targetFps = uiState.preferences.targetFps,
            maxSupportedHz = uiState.displaySpecs.maxSupportedRefreshRateHz,
            onSelectTargetFps = onSelectTargetFps,
          )
          PresetsFooterSection(
            onResetPresets = {
              onResetPresets()
              onShowMessage(presetsResetMsg)
            }
          )
        }
      }
    } else {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
          modifier =
            Modifier.widthIn(max = 620.dp)
              .fillMaxWidth()
              .verticalScroll(rememberScrollState())
              .padding(horizontal = 16.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          ReadinessBannerCard(
            readiness = uiState.readiness,
            selectedGame = uiState.preferences.selectedGame,
            onOpenSettings = openDisplaySettings,
          )
          GameSelectorCard(
            selectedGame = uiState.preferences.selectedGame,
            onSelectGame = onSelectGame,
          )
          GraphicsPreferenceCard(
            selectedTier = uiState.preferences.graphicsPreference,
            onSelectTier = onSelectGraphics,
          )
          TargetFpsPreferenceCard(
            targetFps = uiState.preferences.targetFps,
            maxSupportedHz = uiState.displaySpecs.maxSupportedRefreshRateHz,
            onSelectTargetFps = onSelectTargetFps,
          )
          PresetsFooterSection(
            onResetPresets = {
              onResetPresets()
              onShowMessage(presetsResetMsg)
            }
          )
          Spacer(modifier = Modifier.height(8.dp))
        }
      }
    }
  }
}

@Composable
private fun ReadinessBannerCard(
  readiness: DisplayReadiness,
  selectedGame: GameTitle,
  onOpenSettings: () -> Unit,
) {
  val gameLabel =
    when (selectedGame) {
      GameTitle.FREE_FIRE -> stringResource(R.string.label_game_free_fire)
      GameTitle.FREE_FIRE_MAX -> stringResource(R.string.label_game_free_fire_max)
    }

  val accentColor =
    when (readiness.status) {
      DisplayReadinessStatus.READY -> MaterialTheme.colorScheme.secondary
      DisplayReadinessStatus.SWITCH_DISPLAY_MODE -> MaterialTheme.colorScheme.tertiary
      DisplayReadinessStatus.HARDWARE_LIMITED -> MaterialTheme.colorScheme.primary
    }

  val icon =
    when (readiness.status) {
      DisplayReadinessStatus.READY -> Icons.Filled.CheckCircle
      DisplayReadinessStatus.SWITCH_DISPLAY_MODE -> Icons.Filled.Warning
      DisplayReadinessStatus.HARDWARE_LIMITED -> Icons.Filled.Info
    }

  val title =
    when (readiness.status) {
      DisplayReadinessStatus.READY ->
        stringResource(R.string.label_readiness_ready_title, readiness.targetFps)
      DisplayReadinessStatus.SWITCH_DISPLAY_MODE ->
        stringResource(R.string.label_readiness_switch_title, readiness.maxSupportedHz)
      DisplayReadinessStatus.HARDWARE_LIMITED ->
        stringResource(R.string.label_readiness_limited_title, readiness.maxSupportedHz)
    }

  val description =
    when (readiness.status) {
      DisplayReadinessStatus.READY ->
        stringResource(
          R.string.label_readiness_ready_desc,
          readiness.activeHz,
          readiness.targetFps,
          gameLabel,
        )
      DisplayReadinessStatus.SWITCH_DISPLAY_MODE ->
        stringResource(
          R.string.label_readiness_switch_desc,
          readiness.activeHz,
          readiness.maxSupportedHz,
          readiness.targetFps,
        )
      DisplayReadinessStatus.HARDWARE_LIMITED ->
        stringResource(
          R.string.label_readiness_limited_desc,
          readiness.maxSupportedHz,
          readiness.targetFps,
        )
    }

  Surface(
    shape = RoundedCornerShape(22.dp),
    color = accentColor.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f)),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Icon(
          imageVector = icon,
          contentDescription = stringResource(R.string.cd_readiness_icon),
          tint = accentColor,
          modifier = Modifier.size(22.dp),
        )
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = accentColor,
          fontWeight = FontWeight.Bold,
        )
      }

      Text(
        text = description,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface,
      )

      if (readiness.status == DisplayReadinessStatus.SWITCH_DISPLAY_MODE) {
        Button(
          onClick = onOpenSettings,
          modifier =
            Modifier.fillMaxWidth()
              .heightIn(min = 48.dp)
              .testTag("presets_open_settings_button"),
          shape = RoundedCornerShape(14.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = accentColor,
              contentColor = MaterialTheme.colorScheme.onTertiary,
            ),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
            contentDescription = stringResource(R.string.cd_open_settings),
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.action_open_display_settings),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }
    }
  }
}

@Composable
private fun GameSelectorCard(
  selectedGame: GameTitle,
  onSelectGame: (GameTitle) -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.SportsEsports,
            contentDescription = stringResource(R.string.cd_game_icon),
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
          )
          Text(
            text = stringResource(R.string.label_select_game),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
        }

        Surface(
          shape = RoundedCornerShape(999.dp),
          color = MaterialTheme.colorScheme.secondaryContainer,
        ) {
          Text(
            text = stringResource(R.string.label_saved_locally),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        GameOptionTile(
          title = stringResource(R.string.label_game_free_fire),
          subtitle = stringResource(R.string.label_game_ff_sub),
          selected = selectedGame == GameTitle.FREE_FIRE,
          onClick = { onSelectGame(GameTitle.FREE_FIRE) },
          modifier = Modifier.weight(1f).testTag("game_card_free_fire"),
        )
        GameOptionTile(
          title = stringResource(R.string.label_game_free_fire_max),
          subtitle = stringResource(R.string.label_game_ffmax_sub),
          selected = selectedGame == GameTitle.FREE_FIRE_MAX,
          onClick = { onSelectGame(GameTitle.FREE_FIRE_MAX) },
          modifier = Modifier.weight(1f).testTag("game_card_free_fire_max"),
        )
      }
    }
  }
}

@Composable
private fun GameOptionTile(
  title: String,
  subtitle: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color =
      if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
      else MaterialTheme.colorScheme.surfaceVariant,
    border =
      BorderStroke(
        width = if (selected) 1.5.dp else 1.dp,
        color =
          if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
      ),
    modifier =
      modifier
        .heightIn(min = 76.dp)
        .clip(RoundedCornerShape(16.dp))
        .clickable(onClick = onClick),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color =
          if (selected) MaterialTheme.colorScheme.primary
          else MaterialTheme.colorScheme.onSurface,
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun GraphicsPreferenceCard(
  selectedTier: GraphicsTier,
  onSelectTier: (GraphicsTier) -> Unit,
) {
  val tiers =
    listOf(
      GraphicsTier.SMOOTH to stringResource(R.string.label_gfx_smooth),
      GraphicsTier.STANDARD to stringResource(R.string.label_gfx_standard),
      GraphicsTier.ULTRA to stringResource(R.string.label_gfx_ultra),
      GraphicsTier.MAX to stringResource(R.string.label_gfx_max),
    )

  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = stringResource(R.string.label_graphics_pref),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        tiers.forEach { (tier, label) ->
          val selected = tier == selectedTier
          FilterChip(
            selected = selected,
            onClick = { onSelectTier(tier) },
            label = {
              Text(
                text = label,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
              )
            },
            modifier =
              Modifier.weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("gfx_chip_${tier.storageKey}"),
            shape = RoundedCornerShape(12.dp),
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
          )
        }
      }
    }
  }
}

@Composable
private fun TargetFpsPreferenceCard(
  targetFps: Int,
  maxSupportedHz: Float,
  onSelectTargetFps: (Int) -> Unit,
) {
  val fpsOptions = listOf(60, 90, 120)

  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = stringResource(R.string.label_target_fps),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        fpsOptions.forEach { fps ->
          val selected = targetFps == fps
          val supportedByPanel = maxSupportedHz + 2.0f >= fps
          val frameBudget = 1000f / fps

          Surface(
            shape = RoundedCornerShape(16.dp),
            color =
              if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
              else MaterialTheme.colorScheme.surfaceVariant,
            border =
              BorderStroke(
                width = if (selected) 1.5.dp else 1.dp,
                color =
                  if (selected) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.outline,
              ),
            modifier =
              Modifier.weight(1f)
                .heightIn(min = 92.dp)
                .clip(RoundedCornerShape(16.dp))
                .clickable { onSelectTargetFps(fps) }
                .testTag("fps_chip_$fps"),
          ) {
            Column(
              modifier = Modifier.padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Text(
                text = "$fps FPS",
                style = MaterialTheme.typography.titleMedium,
                fontFamily = JetBrainsMonoFontFamily,
                color =
                  if (selected) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = String.format(Locale.US, "%.2f ms", frameBudget),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Text(
                text =
                  if (supportedByPanel) stringResource(R.string.label_supported_tag)
                  else stringResource(R.string.label_exceeds_hw_tag),
                style = MaterialTheme.typography.labelSmall,
                color =
                  if (supportedByPanel) MaterialTheme.colorScheme.secondary
                  else MaterialTheme.colorScheme.tertiary,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PresetsFooterSection(onResetPresets: () -> Unit) {
  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    OutlinedButton(
      onClick = onResetPresets,
      modifier =
        Modifier.fillMaxWidth()
          .heightIn(min = 48.dp)
          .testTag("reset_presets_button"),
      shape = RoundedCornerShape(14.dp),
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
      Icon(
        imageVector = Icons.Filled.RestartAlt,
        contentDescription = null,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = stringResource(R.string.action_reset_presets),
        style = MaterialTheme.typography.labelLarge,
      )
    }

    Text(
      text = stringResource(R.string.label_presets_disclaimer),
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}
