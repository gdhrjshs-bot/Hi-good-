package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Monitor
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Monitor
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.MonitorTab
import com.example.model.MonitorUiState
import com.example.ui.MonitorViewModel
import com.example.ui.screens.DisplaySpecsScreen
import com.example.ui.screens.JsSourceScreen
import com.example.ui.screens.MonitorScreen
import com.example.ui.screens.PresetsScreen
import com.example.ui.theme.HzMonitorTheme
import com.example.ui.theme.JetBrainsMonoFontFamily
import java.util.Locale
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
    )
    setContent {
      HzMonitorTheme {
        HzMonitorApp()
      }
    }
  }
}

private data class NavItem(
  val tab: MonitorTab,
  val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val tag: String,
)

@Composable
fun HzMonitorApp(viewModel: MonitorViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val lifecycleOwner = LocalLifecycleOwner.current
  val copiedMsg = stringResource(R.string.action_copied)

  // Re-read hardware display modes whenever returning from system settings
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        viewModel.refreshDisplaySpecs()
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  if (uiState.activeTab != MonitorTab.MONITOR) {
    BackHandler { viewModel.selectTab(MonitorTab.MONITOR) }
  }

  val showMessage: (String) -> Unit = { msg ->
    scope.launch { snackbarHostState.showSnackbar(msg) }
  }

  val navItems =
    remember {
      listOf(
        NavItem(
          tab = MonitorTab.MONITOR,
          labelRes = R.string.nav_monitor,
          selectedIcon = Icons.Filled.Speed,
          unselectedIcon = Icons.Outlined.Speed,
          tag = "nav_tab_monitor",
        ),
        NavItem(
          tab = MonitorTab.PRESETS,
          labelRes = R.string.nav_presets,
          selectedIcon = Icons.Filled.SportsEsports,
          unselectedIcon = Icons.Outlined.SportsEsports,
          tag = "nav_tab_presets",
        ),
        NavItem(
          tab = MonitorTab.DISPLAY,
          labelRes = R.string.nav_display,
          selectedIcon = Icons.Filled.Monitor,
          unselectedIcon = Icons.Outlined.Monitor,
          tag = "nav_tab_display",
        ),
        NavItem(
          tab = MonitorTab.SOURCE,
          labelRes = R.string.nav_source,
          selectedIcon = Icons.Filled.Code,
          unselectedIcon = Icons.Outlined.Code,
          tag = "nav_tab_source",
        ),
      )
    }

  BoxWithConstraints(
    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
  ) {
    val useRail = maxWidth >= 720.dp

    if (useRail) {
      Row(modifier = Modifier.fillMaxSize()) {
        NavigationRail(
          containerColor = MaterialTheme.colorScheme.surface,
          windowInsets = WindowInsets.safeDrawing,
          modifier = Modifier.fillMaxHeight(),
        ) {
          navItems.forEach { item ->
            val selected = uiState.activeTab == item.tab
            NavigationRailItem(
              selected = selected,
              onClick = { viewModel.selectTab(item.tab) },
              icon = {
                Icon(
                  imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                  contentDescription = stringResource(item.labelRes),
                )
              },
              label = { Text(text = stringResource(item.labelRes)) },
              modifier = Modifier.testTag(item.tag),
              colors =
                NavigationRailItemDefaults.colors(
                  selectedIconColor = MaterialTheme.colorScheme.primary,
                  selectedTextColor = MaterialTheme.colorScheme.primary,
                  indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                ),
            )
          }
        }

        Scaffold(
          modifier = Modifier.weight(1f).fillMaxHeight(),
          containerColor = MaterialTheme.colorScheme.background,
          snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
          topBar = {
            AppHeaderBar(
              currentHz = uiState.telemetry.currentHz,
              isRunning = uiState.telemetry.isRunning,
            )
          },
        ) { innerPadding ->
          TabContentHost(
            uiState = uiState,
            viewModel = viewModel,
            onCopied = { showMessage(copiedMsg) },
            onShowMessage = showMessage,
            modifier = Modifier.padding(innerPadding),
          )
        }
      }
    } else {
      Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
          AppHeaderBar(
            currentHz = uiState.telemetry.currentHz,
            isRunning = uiState.telemetry.isRunning,
          )
        },
        bottomBar = {
          NavigationBar(
            containerColor = MaterialTheme.colorScheme.surface,
            windowInsets = WindowInsets.navigationBars,
          ) {
            navItems.forEach { item ->
              val selected = uiState.activeTab == item.tab
              NavigationBarItem(
                selected = selected,
                onClick = { viewModel.selectTab(item.tab) },
                icon = {
                  Icon(
                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                    contentDescription = stringResource(item.labelRes),
                  )
                },
                label = { Text(text = stringResource(item.labelRes)) },
                modifier = Modifier.testTag(item.tag),
                colors =
                  NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                  ),
              )
            }
          }
        },
      ) { innerPadding ->
        TabContentHost(
          uiState = uiState,
          viewModel = viewModel,
          onCopied = { showMessage(copiedMsg) },
          onShowMessage = showMessage,
          modifier = Modifier.padding(innerPadding),
        )
      }
    }
  }
}

@Composable
private fun AppHeaderBar(currentHz: Double, isRunning: Boolean) {
  val bgBrush =
    Brush.verticalGradient(
      colors =
        listOf(
          MaterialTheme.colorScheme.surface,
          MaterialTheme.colorScheme.background,
        )
    )
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .background(bgBrush)
        .statusBarsPadding()
        .padding(horizontal = 20.dp, vertical = 14.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
      Text(
        text = stringResource(R.string.app_name),
        style = MaterialTheme.typography.headlineMedium,
        color = MaterialTheme.colorScheme.onBackground,
      )
      Text(
        text = stringResource(R.string.app_subtitle),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }

    Surface(
      shape = RoundedCornerShape(999.dp),
      color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
      ) {
        Box(
          modifier =
            Modifier.size(8.dp)
              .clip(CircleShape)
              .background(
                if (isRunning) MaterialTheme.colorScheme.secondary
                else MaterialTheme.colorScheme.tertiary
              )
        )
        Text(
          text =
            if (currentHz > 0) String.format(Locale.US, "%.0f Hz", currentHz)
            else if (isRunning) stringResource(R.string.status_running)
            else stringResource(R.string.status_paused),
          style = MaterialTheme.typography.labelMedium,
          fontFamily = JetBrainsMonoFontFamily,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }
    }
  }
}

@Composable
private fun TabContentHost(
  uiState: MonitorUiState,
  viewModel: MonitorViewModel,
  onCopied: () -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  when (uiState.activeTab) {
    MonitorTab.MONITOR ->
      MonitorScreen(
        uiState = uiState,
        commands = viewModel.commands,
        onToggleRunning = viewModel::toggleRunning,
        onResetStats = viewModel::resetStats,
        onSelectWindow = viewModel::setSampleWindow,
        onToggleOscilloscope = viewModel::setShowOscilloscope,
        onTelemetryJson = viewModel::onJsTelemetryJson,
        modifier = modifier,
      )
    MonitorTab.PRESETS ->
      PresetsScreen(
        uiState = uiState,
        onSelectGame = viewModel::selectGame,
        onSelectGraphics = viewModel::selectGraphics,
        onSelectTargetFps = viewModel::selectTargetFps,
        onResetPresets = viewModel::resetGamePreferences,
        onShowMessage = onShowMessage,
        modifier = modifier,
      )
    MonitorTab.DISPLAY ->
      DisplaySpecsScreen(
        displaySpecs = uiState.displaySpecs,
        onRefreshDisplay = viewModel::refreshDisplaySpecs,
        onShowMessage = onShowMessage,
        modifier = modifier,
      )
    MonitorTab.SOURCE ->
      JsSourceScreen(
        jsSourceCode = uiState.jsSourceCode,
        onCopied = onCopied,
        modifier = modifier,
      )
  }
}
