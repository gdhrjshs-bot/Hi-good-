package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Monitor
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.DisplayModeInfo
import com.example.model.DisplaySpecs
import com.example.ui.theme.JetBrainsMonoFontFamily
import java.util.Locale

@Composable
fun DisplaySpecsScreen(
  displaySpecs: DisplaySpecs,
  onRefreshDisplay: () -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val settingsUnavailableMsg = stringResource(R.string.action_settings_unavailable)
  val refreshedMsg = stringResource(R.string.action_display_refreshed)

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier =
        Modifier.widthIn(max = 640.dp)
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        HardwareOverviewCard(displaySpecs = displaySpecs)
      }

      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Button(
            onClick = {
              val launched =
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
                  }
                  .isSuccess
              if (!launched) {
                onShowMessage(settingsUnavailableMsg)
              }
            },
            modifier =
              Modifier.fillMaxWidth()
                .heightIn(min = 50.dp)
                .testTag("open_display_settings_button"),
            shape = RoundedCornerShape(16.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.OpenInNew,
              contentDescription = stringResource(R.string.cd_open_settings),
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.action_open_display_settings),
              style = MaterialTheme.typography.labelLarge,
            )
          }

          OutlinedButton(
            onClick = {
              onRefreshDisplay()
              onShowMessage(refreshedMsg)
            },
            modifier =
              Modifier.fillMaxWidth()
                .heightIn(min = 48.dp)
                .testTag("refresh_display_button"),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
          ) {
            Icon(
              imageVector = Icons.Filled.Refresh,
              contentDescription = stringResource(R.string.cd_refresh_display),
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.action_refresh_display),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }

      item {
        Text(
          text = stringResource(R.string.label_supported_modes),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.padding(top = 6.dp),
        )
      }

      items(items = displaySpecs.supportedModes, key = { it.modeId }) { mode ->
        DisplayModeRow(mode = mode)
      }

      item {
        Text(
          text = stringResource(R.string.label_display_limitations),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(top = 6.dp, bottom = 12.dp),
        )
      }
    }
  }
}

@Composable
private fun HardwareOverviewCard(displaySpecs: DisplaySpecs) {
  Surface(
    shape = RoundedCornerShape(22.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    tonalElevation = 2.dp,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Icon(
          imageVector = Icons.Outlined.Monitor,
          contentDescription = stringResource(R.string.cd_display_icon),
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(22.dp),
        )
        Text(
          text = stringResource(R.string.label_display_overview),
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(
          text = String.format(Locale.US, "%.1f", displaySpecs.activeRefreshRateHz),
          style = MaterialTheme.typography.displayLarge,
          color = MaterialTheme.colorScheme.secondary,
        )
        Text(
          text = "Hz",
          style = MaterialTheme.typography.titleLarge,
          fontFamily = JetBrainsMonoFontFamily,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(bottom = 8.dp),
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        SpecBadge(
          label = stringResource(R.string.label_resolution),
          value = "${displaySpecs.widthPx}×${displaySpecs.heightPx}",
          modifier = Modifier.weight(1f),
        )
        SpecBadge(
          label = stringResource(R.string.label_density),
          value = "${displaySpecs.densityDpi} dpi",
          modifier = Modifier.weight(1f),
        )
        SpecBadge(
          label = stringResource(R.string.label_hdr_support),
          value =
            if (displaySpecs.hdrSupported) stringResource(R.string.label_hdr_supported)
            else stringResource(R.string.label_hdr_standard),
          modifier = Modifier.weight(1f),
        )
      }
    }
  }
}

@Composable
private fun SpecBadge(
  label: String,
  value: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surfaceVariant,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Text(
        text = label.uppercase(Locale.US),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.bodyMedium,
        fontFamily = JetBrainsMonoFontFamily,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
      )
    }
  }
}

@Composable
private fun DisplayModeRow(mode: DisplayModeInfo) {
  val frameMs = if (mode.refreshRateHz > 0f) 1000f / mode.refreshRateHz else 16.67f
  Surface(
    shape = RoundedCornerShape(16.dp),
    color =
      if (mode.isActive) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
      else MaterialTheme.colorScheme.surface,
    border =
      BorderStroke(
        width = 1.dp,
        color =
          if (mode.isActive) MaterialTheme.colorScheme.secondary
          else MaterialTheme.colorScheme.outline,
      ),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
          text = String.format(Locale.US, "%.1f Hz", mode.refreshRateHz),
          style = MaterialTheme.typography.titleMedium,
          fontFamily = JetBrainsMonoFontFamily,
          color =
            if (mode.isActive) MaterialTheme.colorScheme.secondary
            else MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text =
            "${mode.widthPx} × ${mode.heightPx}  •  " +
              String.format(Locale.US, "%.2f ms/frame", frameMs),
          style = MaterialTheme.typography.bodyMedium,
          fontFamily = JetBrainsMonoFontFamily,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      if (mode.isActive) {
        Surface(
          shape = RoundedCornerShape(999.dp),
          color = MaterialTheme.colorScheme.secondary,
        ) {
          Text(
            text = stringResource(R.string.label_active_mode),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
          )
        }
      }
    }
  }
}
