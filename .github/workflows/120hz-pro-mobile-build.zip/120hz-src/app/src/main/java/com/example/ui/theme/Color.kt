package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF090D16)
val SlateSurface = Color(0xFF111A2E)
val SlateSurfaceHigh = Color(0xFF18243E)
val SlateOutline = Color(0xFF28354F)

val ElectricCyan = Color(0xFF22D3EE)
val ElectricCyanContainer = Color(0xFF0E3A4A)
val EmeraldSignal = Color(0xFF34D399)
val EmeraldContainer = Color(0xFF0F3B2E)
val AmberWarn = Color(0xFFFBBF24)
val CoralAlert = Color(0xFFFB7185)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val OnAccentDark = Color(0xFF04131C)
