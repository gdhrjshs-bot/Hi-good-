package com.example.model

enum class MonitorTab {
  MONITOR,
  PRESETS,
  DISPLAY,
  SOURCE,
}

enum class GameTitle(val storageKey: String) {
  FREE_FIRE("free_fire"),
  FREE_FIRE_MAX("free_fire_max");

  companion object {
    fun fromKey(key: String?): GameTitle =
      entries.firstOrNull { it.storageKey == key } ?: FREE_FIRE_MAX
  }
}

enum class GraphicsTier(val storageKey: String) {
  SMOOTH("smooth"),
  STANDARD("standard"),
  ULTRA("ultra"),
  MAX("max");

  companion object {
    fun fromKey(key: String?): GraphicsTier =
      entries.firstOrNull { it.storageKey == key } ?: ULTRA
  }
}

data class UserPreferences(
  val selectedGame: GameTitle = GameTitle.FREE_FIRE_MAX,
  val graphicsPreference: GraphicsTier = GraphicsTier.ULTRA,
  val targetFps: Int = 120,
  val sampleWindowMs: Int = 500,
  val showOscilloscope: Boolean = true,
)

enum class DisplayReadinessStatus {
  READY,
  SWITCH_DISPLAY_MODE,
  HARDWARE_LIMITED,
}

data class DisplayReadiness(
  val status: DisplayReadinessStatus,
  val activeHz: Float,
  val maxSupportedHz: Float,
  val targetFps: Int,
)

data class JsTelemetrySnapshot(
  val currentHz: Double = 0.0,
  val avgFrameMs: Double = 0.0,
  val minHz: Double = 0.0,
  val maxHz: Double = 0.0,
  val avgHz: Double = 0.0,
  val jitterMs: Double = 0.0,
  val droppedFrames: Int = 0,
  val totalFrames: Int = 0,
  val isRunning: Boolean = true,
  val sampleWindowMs: Int = 500,
)

data class DisplayModeInfo(
  val modeId: Int,
  val widthPx: Int,
  val heightPx: Int,
  val refreshRateHz: Float,
  val isActive: Boolean,
)

data class DisplaySpecs(
  val activeRefreshRateHz: Float = 60f,
  val widthPx: Int = 0,
  val heightPx: Int = 0,
  val densityDpi: Int = 0,
  val hdrSupported: Boolean = false,
  val supportedModes: List<DisplayModeInfo> = emptyList(),
) {
  val maxSupportedRefreshRateHz: Float
    get() = supportedModes.maxOfOrNull { it.refreshRateHz } ?: activeRefreshRateHz
}

sealed interface JsCommand {
  data object Start : JsCommand
  data object Pause : JsCommand
  data object Reset : JsCommand
  data class SetWindow(val windowMs: Int) : JsCommand
  data class SetOscilloscope(val visible: Boolean) : JsCommand
}

data class MonitorUiState(
  val activeTab: MonitorTab = MonitorTab.MONITOR,
  val telemetry: JsTelemetrySnapshot = JsTelemetrySnapshot(),
  val displaySpecs: DisplaySpecs = DisplaySpecs(),
  val preferences: UserPreferences = UserPreferences(),
  val readiness: DisplayReadiness =
    DisplayReadiness(
      status = DisplayReadinessStatus.HARDWARE_LIMITED,
      activeHz = 60f,
      maxSupportedHz = 60f,
      targetFps = 120,
    ),
  val jsSourceCode: String = "",
)
