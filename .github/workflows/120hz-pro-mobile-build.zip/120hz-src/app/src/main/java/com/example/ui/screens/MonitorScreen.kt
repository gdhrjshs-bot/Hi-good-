package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.JsCommand
import com.example.model.MonitorUiState
import com.example.ui.components.JsFrameRateMonitorView
import com.example.ui.theme.JetBrainsMonoFontFamily
import java.util.Locale
import kotlinx.coroutines.flow.SharedFlow

@Composable
fun MonitorScreen(
  uiState: MonitorUiState,
  commands: SharedFlow<JsCommand>,
  onToggleRunning: () -> Unit,
  onResetStats: () -> Unit,
  onSelectWindow: (Int) -> Unit,
  onToggleOscilloscope: (Boolean) -> Unit,
  onTelemetryJson: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val prefs = uiState.preferences

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 720.dp

    if (isWide) {
      Row(
        modifier =
          Modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp),
        verticalAlignment = Alignment.Top,
      ) {
        JsFrameRateMonitorView(
          commands = commands,
          sampleWindowMs = prefs.sampleWindowMs,
          showOscilloscope = prefs.showOscilloscope,
          isRunning = uiState.telemetry.isRunning,
          onTelemetryJson = onTelemetryJson,
          modifier = Modifier.weight(1.15f),
        )
        Column(
          modifier = Modifier.weight(0.85f),
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          MonitorControlsCard(
            isRunning = uiState.telemetry.isRunning,
            sampleWindowMs = prefs.sampleWindowMs,
            showOscilloscope = prefs.showOscilloscope,
            onToggleRunning = onToggleRunning,
            onResetStats = onResetStats,
            onSelectWindow = onSelectWindow,
            onToggleOscilloscope = onToggleOscilloscope,
          )
          SyncComparisonCard(uiState = uiState)
        }
      }
    } else {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
          modifier =
            Modifier.widthIn(max = 620.dp)
              .fillMaxWidth()
              .verticalScroll(rememberScrollState())
              .padding(horizontal = 16.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          JsFrameRateMonitorView(
            commands = commands,
            sampleWindowMs = prefs.sampleWindowMs,
            showOscilloscope = prefs.showOscilloscope,
            isRunning = uiState.telemetry.isRunning,
            onTelemetryJson = onTelemetryJson,
          )
          MonitorControlsCard(
            isRunning = uiState.telemetry.isRunning,
            sampleWindowMs = prefs.sampleWindowMs,
            showOscilloscope = prefs.showOscilloscope,
            onToggleRunning = onToggleRunning,
            onResetStats = onResetStats,
            onSelectWindow = onSelectWindow,
            onToggleOscilloscope = onToggleOscilloscope,
          )
          SyncComparisonCard(uiState = uiState)
          Spacer(modifier = Modifier.height(8.dp))
        }
      }
    }
  }
}

@Composable
private fun MonitorControlsCard(
  isRunning: Boolean,
  sampleWindowMs: Int,
  showOscilloscope: Boolean,
  onToggleRunning: () -> Unit,
  onResetStats: () -> Unit,
  onSelectWindow: (Int) -> Unit,
  onToggleOscilloscope: (Boolean) -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    tonalElevation = 2.dp,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Outlined.Tune,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(18.dp),
        )
        Text(
          text = stringResource(R.string.label_sample_window),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = onToggleRunning,
          modifier =
            Modifier.weight(1f)
              .heightIn(min = 48.dp)
              .testTag("toggle_running_button"),
          shape = RoundedCornerShape(14.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor =
                if (isRunning) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.secondary,
              contentColor =
                if (isRunning) MaterialTheme.colorScheme.onPrimaryContainer
                else MaterialTheme.colorScheme.onSecondary,
            ),
        ) {
          Icon(
            imageVector = if (isRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            contentDescription = stringResource(R.string.cd_toggle_running),
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text =
              if (isRunning) stringResource(R.string.action_pause)
              else stringResource(R.string.action_resume),
            style = MaterialTheme.typography.labelLarge,
          )
        }

        OutlinedButton(
          onClick = onResetStats,
          modifier =
            Modifier.weight(1f)
              .heightIn(min = 48.dp)
              .testTag("reset_stats_button"),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Icon(
            imageVector = Icons.Filled.Refresh,
            contentDescription = stringResource(R.string.cd_reset_stats),
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.action_reset),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        val windows =
          listOf(
            250 to stringResource(R.string.window_250ms),
            500 to stringResource(R.string.window_500ms),
            1000 to stringResource(R.string.window_1000ms),
          )
        windows.forEach { (ms, label) ->
          val selected = sampleWindowMs == ms
          FilterChip(
            selected = selected,
            onClick = { onSelectWindow(ms) },
            label = {
              Text(
                text = label,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
              )
            },
            modifier =
              Modifier.weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("window_chip_$ms"),
            shape = RoundedCornerShape(12.dp),
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.label_oscilloscope_toggle),
          style = MaterialTheme.typography.bodyLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Switch(
          checked = showOscilloscope,
          onCheckedChange = onToggleOscilloscope,
          modifier = Modifier.testTag("oscilloscope_switch"),
          colors =
            SwitchDefaults.colors(
              checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
              checkedTrackColor = MaterialTheme.colorScheme.primary,
            ),
        )
      }
    }
  }
}

@Composable
private fun SyncComparisonCard(uiState: MonitorUiState) {
  val telemetry = uiState.telemetry
  val reportedHz = uiState.displaySpecs.activeRefreshRateHz
  val targetBudgetMs = if (reportedHz > 0f) 1000f / reportedHz else 16.67f

  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    tonalElevation = 2.dp,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Outlined.Speed,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.secondary,
          modifier = Modifier.size(18.dp),
        )
        Text(
          text = stringResource(R.string.label_session_stats),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        StatTile(
          label = stringResource(R.string.label_js_measured),
          value =
            if (telemetry.currentHz > 0)
              String.format(Locale.US, "%.1f Hz", telemetry.currentHz)
            else "--.- Hz",
          highlight = true,
          modifier = Modifier.weight(1f),
        )
        StatTile(
          label = stringResource(R.string.label_android_reported),
          value = String.format(Locale.US, "%.1f Hz", reportedHz),
          highlight = false,
          modifier = Modifier.weight(1f),
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        StatTile(
          label = stringResource(R.string.label_avg_hz),
          value =
            if (telemetry.avgHz > 0) String.format(Locale.US, "%.1f Hz", telemetry.avgHz)
            else "--.- Hz",
          highlight = false,
          modifier = Modifier.weight(1f),
        )
        StatTile(
          label = stringResource(R.string.label_frame_budget),
          value = String.format(Locale.US, "%.2f ms", targetBudgetMs),
          highlight = false,
          modifier = Modifier.weight(1f),
        )
        StatTile(
          label = stringResource(R.string.label_frames),
          value = telemetry.totalFrames.toString(),
          highlight = false,
          modifier = Modifier.weight(1f),
        )
      }
    }
  }
}

@Composable
private fun StatTile(
  label: String,
  value: String,
  highlight: Boolean,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surfaceVariant,
    border =
      BorderStroke(
        width = 1.dp,
        color =
          if (highlight) MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
          else MaterialTheme.colorScheme.outline.copy(alpha = 0.7f),
      ),
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Text(
        text = label.uppercase(Locale.US),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium,
        fontFamily = JetBrainsMonoFontFamily,
        color =
          if (highlight) MaterialTheme.colorScheme.primary
          else MaterialTheme.colorScheme.onSurface,
      )
    }
  }
}
