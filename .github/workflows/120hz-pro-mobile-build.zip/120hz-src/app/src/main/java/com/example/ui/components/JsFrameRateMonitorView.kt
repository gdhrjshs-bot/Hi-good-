package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.model.JsCommand
import java.io.ByteArrayInputStream
import kotlinx.coroutines.flow.SharedFlow

private const val ASSET_HOST = "appassets.androidplatform.net"
private const val ENTRY_URL = "https://$ASSET_HOST/assets/fps_monitor.html"
private const val MAX_AUTO_RELOADS = 2

private class AndroidHzBridge(private val onTelemetryReceived: (String) -> Unit) {
  @JavascriptInterface
  fun onTelemetry(jsonPayload: String) {
    onTelemetryReceived(jsonPayload)
  }
}

private open class LocalAssetWebViewClient(
  private val appContext: Context,
  private val onRendererCrashed: () -> Unit,
) : WebViewClient() {

  override fun shouldInterceptRequest(
    view: WebView,
    request: WebResourceRequest,
  ): WebResourceResponse? {
    val uri: Uri = request.url
    if (uri.scheme != "https" || uri.host != ASSET_HOST) {
      return emptyBlockedResponse()
    }
    if (uri.path == "/favicon.ico") {
      return WebResourceResponse(
        "image/x-icon",
        "UTF-8",
        204,
        "No Content",
        emptyMap(),
        ByteArrayInputStream(ByteArray(0)),
      )
    }
    val assetName =
      when (uri.path) {
        "/assets/fps_monitor.html" -> "fps_monitor.html" to "text/html"
        "/assets/fps_monitor.js" -> "fps_monitor.js" to "application/javascript"
        else -> null
      } ?: return emptyBlockedResponse()

    return runCatching {
        val stream = appContext.assets.open(assetName.first)
        WebResourceResponse(assetName.second, "UTF-8", stream)
      }
      .getOrElse { emptyBlockedResponse() }
  }

  override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
    return true
  }

  override fun onRenderProcessGone(
    view: WebView,
    detail: RenderProcessGoneDetail,
  ): Boolean {
    // Handle renderer crashes gracefully so Android never terminates the host app
    onRendererCrashed()
    return true
  }

  private fun emptyBlockedResponse(): WebResourceResponse =
    WebResourceResponse(
      "text/plain",
      "UTF-8",
      403,
      "Forbidden",
      emptyMap(),
      ByteArrayInputStream(ByteArray(0)),
    )
}

private fun safelyDestroyWebView(webView: WebView) {
  runCatching {
    webView.stopLoading()
    webView.webViewClient = WebViewClient()
    webView.removeJavascriptInterface("AndroidHzBridge")
    (webView.parent as? ViewGroup)?.removeView(webView)
    webView.removeAllViews()
    webView.destroy()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun JsFrameRateMonitorView(
  commands: SharedFlow<JsCommand>,
  sampleWindowMs: Int,
  showOscilloscope: Boolean,
  isRunning: Boolean,
  onTelemetryJson: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val lifecycleOwner = LocalLifecycleOwner.current
  val latestTelemetryCallback by rememberUpdatedState(onTelemetryJson)
  val latestIsRunning by rememberUpdatedState(isRunning)
  val latestSampleWindow by rememberUpdatedState(sampleWindowMs)
  val latestShowOscilloscope by rememberUpdatedState(showOscilloscope)

  var webViewRef by remember { mutableStateOf<WebView?>(null) }
  var reloadGeneration by remember { mutableIntStateOf(0) }
  var crashCount by remember { mutableIntStateOf(0) }
  var rendererFailed by remember { mutableStateOf(false) }

  val targetHeight by
    animateDpAsState(
      targetValue = if (showOscilloscope) 576.dp else 422.dp,
      animationSpec = spring(),
      label = "js_monitor_height",
    )

  LaunchedEffect(commands, webViewRef) {
    commands.collect { cmd ->
      val wv = webViewRef ?: return@collect
      val js =
        when (cmd) {
          JsCommand.Start -> "window.fpsMonitor && window.fpsMonitor.start();"
          JsCommand.Pause -> "window.fpsMonitor && window.fpsMonitor.pause();"
          JsCommand.Reset -> "window.fpsMonitor && window.fpsMonitor.reset();"
          is JsCommand.SetWindow ->
            "window.fpsMonitor && window.fpsMonitor.setSampleWindow(${cmd.windowMs});"
          is JsCommand.SetOscilloscope ->
            "window.fpsMonitor && window.fpsMonitor.setOscilloscopeVisible(${cmd.visible});"
        }
      runCatching { wv.evaluateJavascript(js, null) }
    }
  }

  DisposableEffect(lifecycleOwner, webViewRef) {
    val observer = LifecycleEventObserver { _, event ->
      val wv = webViewRef ?: return@LifecycleEventObserver
      when (event) {
        Lifecycle.Event.ON_RESUME -> {
          runCatching {
            wv.onResume()
            if (latestIsRunning) {
              wv.evaluateJavascript("window.fpsMonitor && window.fpsMonitor.start();", null)
            }
          }
        }
        Lifecycle.Event.ON_PAUSE -> {
          runCatching {
            wv.evaluateJavascript("window.fpsMonitor && window.fpsMonitor.pause();", null)
            wv.onPause()
          }
        }
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  if (rendererFailed) {
    Surface(
      shape = RoundedCornerShape(22.dp),
      color = MaterialTheme.colorScheme.surface,
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
      modifier = modifier.fillMaxWidth().padding(vertical = 4.dp),
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = stringResource(R.string.label_monitor_reloading),
          style = MaterialTheme.typography.bodyLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Button(
          onClick = {
            crashCount = 0
            rendererFailed = false
            reloadGeneration += 1
          },
          modifier = Modifier.heightIn(min = 48.dp).testTag("reload_js_monitor_button"),
          shape = RoundedCornerShape(14.dp),
        ) {
          Text(text = stringResource(R.string.action_reload_monitor))
        }
      }
    }
    return
  }

  key(reloadGeneration) {
    AndroidView(
      modifier = modifier.fillMaxWidth().height(targetHeight).testTag("js_fps_monitor_webview"),
      factory = { context ->
        WebView(context).apply {
          layoutParams =
            ViewGroup.LayoutParams(
              ViewGroup.LayoutParams.MATCH_PARENT,
              ViewGroup.LayoutParams.MATCH_PARENT,
            )
          setBackgroundColor(0xFF090D16.toInt())
          overScrollMode = View.OVER_SCROLL_NEVER
          isVerticalScrollBarEnabled = false
          isHorizontalScrollBarEnabled = false

          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
          }

          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
          }

          val bridge = AndroidHzBridge { payload -> latestTelemetryCallback(payload) }
          addJavascriptInterface(bridge, "AndroidHzBridge")

          webViewClient =
            object :
              LocalAssetWebViewClient(
                appContext = context.applicationContext,
                onRendererCrashed = {
                  webViewRef = null
                  if (crashCount < MAX_AUTO_RELOADS) {
                    crashCount += 1
                    reloadGeneration += 1
                  } else {
                    rendererFailed = true
                  }
                },
              ) {
              override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                val startOrPause = if (latestIsRunning) "start" else "pause"
                view.evaluateJavascript(
                  "window.fpsMonitor && (window.fpsMonitor.setSampleWindow($latestSampleWindow), " +
                    "window.fpsMonitor.setOscilloscopeVisible($latestShowOscilloscope), " +
                    "window.fpsMonitor.$startOrPause());",
                  null,
                )
              }
            }

          loadUrl(ENTRY_URL)
          webViewRef = this
        }
      },
      onRelease = { webView ->
        if (webViewRef === webView) {
          webViewRef = null
        }
        safelyDestroyWebView(webView)
      },
    )
  }
}
