package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TelemetryDarkColorScheme =
  darkColorScheme(
    primary = ElectricCyan,
    onPrimary = OnAccentDark,
    primaryContainer = ElectricCyanContainer,
    onPrimaryContainer = ElectricCyan,
    secondary = EmeraldSignal,
    onSecondary = OnAccentDark,
    secondaryContainer = EmeraldContainer,
    onSecondaryContainer = EmeraldSignal,
    tertiary = AmberWarn,
    onTertiary = OnAccentDark,
    error = CoralAlert,
    onError = OnAccentDark,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = SlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurfaceHigh,
    onSurfaceVariant = TextSecondary,
    outline = SlateOutline,
    outlineVariant = SlateOutline,
  )

@Composable
fun HzMonitorTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = TelemetryDarkColorScheme,
    typography = AppTypography,
    content = content,
  )
}
